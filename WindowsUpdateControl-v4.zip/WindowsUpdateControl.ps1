#requires -Version 5.1
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [ValidateSet('Disable', 'Restore', 'Status', 'DisableService', 'RestoreService')]
    [string]$Action = 'Status',
    [switch]$Pause
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$policyPath = 'SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
$backupPath = 'SOFTWARE\WindowsUpdateControlLocal'
$base = $null
$mutex = $null
$locked = $false
$resultCode = 0
$servicePath = 'SYSTEM\CurrentControlSet\Services\wuauserv'

function Read-UpdateService {
    $key = $base.OpenSubKey($servicePath, $false)
    if ($null -eq $key) { throw 'Windows Update service is not installed.' }
    try {
        $start = $key.GetValue('Start')
        if ($start -notin @(2, 3, 4)) { throw 'Unexpected service startup configuration.' }
        $delayedPresent = $key.GetValueNames() -contains 'DelayedAutoStart'
        $delayed = if ($delayedPresent) { $key.GetValue('DelayedAutoStart') } else { 0 }
        if ($delayedPresent -and ($key.GetValueKind('DelayedAutoStart') -ne
            [Microsoft.Win32.RegistryValueKind]::DWord -or $delayed -notin @(0, 1))) {
            throw 'Unexpected delayed-start configuration.'
        }
        $service = Get-Service -Name wuauserv
        try {
            if ([string]$service.Status -notin @('Running', 'Stopped')) {
                throw 'Service is transitioning or paused. Wait and try again.'
            }
            return [pscustomobject]@{ Version = 1; Start = [int]$start;
                DelayedPresent = $delayedPresent; DelayedValue = [int]$delayed;
                Running = ([string]$service.Status -eq 'Running') }
        } finally { $service.Dispose() }
    } finally { $key.Dispose() }
}

function Read-ServiceBackup {
    $key = $base.OpenSubKey($backupPath, $false)
    try {
        if ($null -eq $key) { return $null }
        $json = $key.GetValue('OriginalService', $null)
        if ($null -eq $json) { return $null }
        $saved = $json | ConvertFrom-Json
        if ($saved.Version -ne 1 -or $saved.Start -isnot [int] -or $saved.Start -notin @(2, 3, 4) -or
            $saved.DelayedPresent -isnot [bool] -or $saved.DelayedValue -isnot [int] -or
            $saved.DelayedValue -notin @(0, 1) -or $saved.Running -isnot [bool]) {
            throw 'Service backup is invalid. No changes were made.'
        }
        return $saved
    } finally { if ($null -ne $key) { $key.Dispose() } }
}

function Set-UpdateServiceRunning([bool]$Running) {
    $service = Get-Service -Name wuauserv
    try {
        if ($Running) {
            if ([string]$service.Status -ne 'Running') { $service.Start() }
            $service.WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Running, [TimeSpan]::FromSeconds(20))
        } else {
            if ([string]$service.Status -ne 'Stopped') { $service.Stop() }
            $service.WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Stopped, [TimeSpan]::FromSeconds(20))
        }
    } finally { $service.Dispose() }
}

function Invoke-ServiceAction {
    $state = Read-UpdateService
    $saved = Read-ServiceBackup
    if ($Action -eq 'DisableService') {
        if ($null -eq $saved) {
            $key = $base.CreateSubKey($backupPath)
            try {
                $key.SetValue('OriginalService', ($state | ConvertTo-Json -Compress),
                    [Microsoft.Win32.RegistryValueKind]::String)
                $key.Flush()
            } finally { $key.Dispose() }
            $saved = Read-ServiceBackup
            if ($null -eq $saved) { throw 'Service backup verification failed.' }
        }
        Set-Service -Name wuauserv -StartupType Disabled
        Set-UpdateServiceRunning $false
        $check = Read-UpdateService
        if ($check.Start -ne 4 -or $check.Running) { throw 'Service disable verification failed. Backup retained.' }
        Write-Host 'Success: Windows Update (wuauserv) is disabled and stopped.' -ForegroundColor Green
    } else {
        if ($null -eq $saved) { throw 'No service backup found. Nothing was changed.' }
        # A disabled service can still have been running when originally captured.
        $startup = switch ($saved.Start) { 2 { 'Automatic' } 3 { 'Manual' } 4 { 'Disabled' } }
        if ($saved.Running -and $saved.Start -eq 4) {
            Set-Service -Name wuauserv -StartupType Manual
            Set-UpdateServiceRunning $true
        }
        Set-Service -Name wuauserv -StartupType $startup
        $key = $base.OpenSubKey($servicePath, $true)
        try {
            if ($saved.DelayedPresent) {
                $key.SetValue('DelayedAutoStart', [int]$saved.DelayedValue, [Microsoft.Win32.RegistryValueKind]::DWord)
            } else { $key.DeleteValue('DelayedAutoStart', $false) }
        } finally { $key.Dispose() }
        Set-UpdateServiceRunning $saved.Running
        $check = Read-UpdateService
        if ($check.Start -ne $saved.Start -or $check.Running -ne $saved.Running -or
            $check.DelayedPresent -ne $saved.DelayedPresent -or
            ($saved.DelayedPresent -and $check.DelayedValue -ne $saved.DelayedValue)) {
            throw 'Service restore verification failed. Backup retained.'
        }
        $key = $base.OpenSubKey($backupPath, $true)
        try { $key.DeleteValue('OriginalService', $false) } finally { $key.Dispose() }
        Write-Host 'Success: original Windows Update service settings restored.' -ForegroundColor Green
    }
}

function Read-Policy {
    $key = $base.OpenSubKey($policyPath, $false)
    try {
        if ($null -eq $key -or $key.GetValueNames() -notcontains 'NoAutoUpdate') {
            return [pscustomobject]@{ Present = $false; Value = 0 }
        }
        if ($key.GetValueKind('NoAutoUpdate') -ne [Microsoft.Win32.RegistryValueKind]::DWord) {
            throw 'NoAutoUpdate has an unexpected type. No changes were made.'
        }
        return [pscustomobject]@{ Present = $true; Value = [int]$key.GetValue('NoAutoUpdate') }
    } finally { if ($null -ne $key) { $key.Dispose() } }
}

function Read-Backup {
    $key = $base.OpenSubKey($backupPath, $false)
    try {
        if ($null -eq $key) { return $null }
        $json = $key.GetValue('OriginalPolicy', $null)
        if ($null -eq $json) { return $null }
        $saved = $json | ConvertFrom-Json
        if ($saved.Version -ne 1 -or $saved.Present -isnot [bool] -or
            $saved.Value -isnot [int]) { throw 'Backup is invalid; refusing to modify policy.' }
        return $saved
    } finally { if ($null -ne $key) { $key.Dispose() } }
}

try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Windows is required.' }
    $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey(
        [Microsoft.Win32.RegistryHive]::LocalMachine, [Microsoft.Win32.RegistryView]::Registry64)

    if ($Action -eq 'Status') {
        $state = Read-Policy
        $backup = Read-Backup
        if (-not $state.Present) { Write-Host 'NoAutoUpdate: not configured.' }
        elseif ($state.Value -eq 1) { Write-Host 'NoAutoUpdate: 1 (automatic updates disabled by this policy).' }
        else { Write-Host ('NoAutoUpdate: {0} (not disabled by this policy).' -f $state.Value) }
        Write-Host ('Restore backup available: {0}' -f ($null -ne $backup))
        Write-Host 'This reports registry configuration, not actual update activity.'
        $serviceState = Read-UpdateService
        Write-Host ('wuauserv: Start={0}, Running={1}, Delayed={2}' -f $serviceState.Start, $serviceState.Running, $serviceState.DelayedValue)
        Write-Host ('Service restore backup available: {0}' -f ($null -ne (Read-ServiceBackup)))
    }
    elseif ($PSCmdlet.ShouldProcess('HKLM automatic-update policy', $Action)) {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        try { $admin = ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole(
                [Security.Principal.WindowsBuiltInRole]::Administrator) }
        finally { $identity.Dispose() }
        if (-not $admin) {
            # Use the script path as a quoted -File argument, never as executable code.
            $engine = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
            $arguments = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -Action {1}' -f $PSCommandPath, $Action
            if ($Pause) { $arguments += ' -Pause' }
            $child = Start-Process -FilePath $engine -ArgumentList $arguments -Verb RunAs -Wait -PassThru
            exit $child.ExitCode
        }
        $mutex = [Threading.Mutex]::new($false, 'Global\WindowsUpdateControlLocalV1')
        try { $locked = $mutex.WaitOne(0) }
        catch [Threading.AbandonedMutexException] { $locked = $true }
        if (-not $locked) { throw 'Another operation is running. Try again after it finishes.' }
        if ($Action -in @('DisableService', 'RestoreService')) {
            Invoke-ServiceAction
        } else {
        $state = Read-Policy
        $backup = Read-Backup

        if ($Action -eq 'Disable') {
            if ($null -eq $backup) {
                $saved = [ordered]@{ Version = 1; Present = $state.Present; Value = $state.Value }
                $key = $base.CreateSubKey($backupPath)
                try {
                    $key.SetValue('OriginalPolicy', ($saved | ConvertTo-Json -Compress),
                        [Microsoft.Win32.RegistryValueKind]::String)
                    $key.Flush()
                } finally { $key.Dispose() }
                $backup = Read-Backup
                if ($null -eq $backup) { throw 'Backup verification failed.' }
            }
            $key = $base.CreateSubKey($policyPath)
            try { $key.SetValue('NoAutoUpdate', 1, [Microsoft.Win32.RegistryValueKind]::DWord) }
            finally { $key.Dispose() }
            $check = Read-Policy
            if (-not $check.Present -or $check.Value -ne 1) { throw 'Policy verification failed. Backup retained.' }
            Write-Host 'Success: NoAutoUpdate=1. Original setting is backed up.' -ForegroundColor Green
        }
        else {
            if ($null -eq $backup) { throw 'No backup found. Nothing was changed.' }
            if ($backup.Present) {
                $key = $base.CreateSubKey($policyPath)
                try { $key.SetValue('NoAutoUpdate', [int]$backup.Value, [Microsoft.Win32.RegistryValueKind]::DWord) }
                finally { $key.Dispose() }
            }
            else {
                $key = $base.OpenSubKey($policyPath, $true)
                if ($null -ne $key) {
                    try { $key.DeleteValue('NoAutoUpdate', $false) } finally { $key.Dispose() }
                }
            }
            $check = Read-Policy
            if ($check.Present -ne $backup.Present -or
                ($backup.Present -and $check.Value -ne $backup.Value)) {
                throw 'Restore verification failed. Backup retained.'
            }
            $key = $base.OpenSubKey($backupPath, $true)
            try { $key.DeleteValue('OriginalPolicy', $false) } finally { $key.Dispose() }
            Write-Host 'Success: original policy restored (it may itself disable updates).' -ForegroundColor Green
        }
        }
        Write-Host 'Restart Windows when convenient so the update client can re-read policy.'
        Write-Host 'Home editions or organization management may ignore/override this setting.'
        Write-Host 'Already pending updates are not cancelled. Check Status after restarting.'
    }
}
catch {
    $resultCode = 1
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
}
finally {
    if ($locked) { $mutex.ReleaseMutex() }
    if ($null -ne $mutex) { $mutex.Dispose() }
    if ($null -ne $base) { $base.Dispose() }
}
if ($Pause) { [void](Read-Host 'Press Enter to close') }
exit $resultCode
