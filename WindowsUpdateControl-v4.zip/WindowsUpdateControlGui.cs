using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.ComponentModel;
using System.Windows.Forms;
using Microsoft.Win32;
using System.ServiceProcess;

public sealed class UpdateControlForm : Form
{
    private readonly Label status = new Label();
    private readonly Label backup = new Label();
    private readonly TextBox log = new TextBox();
    private readonly Button disable = new Button();
    private readonly Button restore = new Button();
    private readonly Button refresh = new Button();
    private readonly Button disableService = new Button();
    private readonly Button restoreService = new Button();
    private readonly Button drivers = new Button();
    private readonly Label serviceStatus = new Label();
    private readonly Timer timer = new Timer();
    private Process operation;
    private string currentAction;
    private bool hasBackup;
    private const string PolicyPath = @"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU";
    private const string BackupPath = @"SOFTWARE\WindowsUpdateControlLocal";

    public UpdateControlForm()
    {
        Text = "Windows 自动更新控制";
        Font = new Font("Microsoft YaHei UI", 10F);
        AutoScaleMode = AutoScaleMode.Dpi;
        ClientSize = new Size(610, 544);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        var title = new Label { Text = "Windows 自动更新控制", AutoSize = true,
            Location = new Point(22, 20), Font = new Font(Font.FontFamily, 16F, FontStyle.Bold) };
        status.SetBounds(24, 66, 560, 28);
        backup.SetBounds(24, 98, 560, 26);
        disable.Text = "阻止自动更新";
        restore.Text = "恢复原设置";
        refresh.Text = "查看状态";
        disable.SetBounds(24, 142, 176, 42);
        restore.SetBounds(216, 142, 176, 42);
        refresh.SetBounds(408, 142, 176, 42);
        serviceStatus.SetBounds(24, 200, 560, 28);
        disableService.Text = "禁用更新服务";
        restoreService.Text = "恢复服务原设置";
        disableService.SetBounds(24, 240, 270, 42);
        restoreService.SetBounds(310, 240, 274, 42);
        var note = new Label { Text = "策略与服务分别备份、分别恢复。修改时需要管理员授权。\r\n禁用服务会影响手动更新；系统维护或管理策略可能重新启用服务。",
            Location = new Point(24, 301), Size = new Size(560, 48), ForeColor = Color.DimGray };
        drivers.Text = "管理驱动扩展更新（NPU / 声卡 / 显卡）";
        drivers.SetBounds(24, 350, 560, 36);
        log.SetBounds(24, 400, 560, 120);
        log.Multiline = true;
        log.ReadOnly = true;
        log.ScrollBars = ScrollBars.Vertical;
        log.BackColor = SystemColors.Window;
        Controls.AddRange(new Control[] { title, status, backup, disable, restore, refresh, serviceStatus, disableService, restoreService, drivers, note, log });
        disable.Click += delegate { BeginOperation("Disable"); };
        restore.Click += delegate { BeginOperation("Restore"); };
        refresh.Click += delegate { RefreshStatus(); };
        disableService.Click += delegate { BeginOperation("DisableService"); };
        restoreService.Click += delegate { BeginOperation("RestoreService"); };
        drivers.Click += delegate {
            try {
                var info = new ProcessStartInfo(Application.ExecutablePath, "--drivers");
                info.UseShellExecute = true;
                info.Verb = "runas";
                using (var process = Process.Start(info)) { }
            } catch (Win32Exception ex) {
                AddLog(ex.NativeErrorCode == 1223 ? "已取消管理员授权。" : "启动失败：" + ex.Message);
            } catch (Exception ex) { AddLog("启动失败：" + ex.Message); }
        };
        timer.Interval = 300;
        timer.Tick += delegate { PollOperation(); };
        FormClosing += delegate(object sender, FormClosingEventArgs e) {
            if (operation != null) {
                e.Cancel = true;
                MessageBox.Show(this, "正在执行，请等待操作结束后关闭。", Text);
            }
        };
        RefreshStatus();
    }

    private void AddLog(string message)
    {
        log.AppendText(DateTime.Now.ToString("HH:mm:ss") + "  " + message + Environment.NewLine);
    }

    public void RefreshStatus()
    {
        try {
            using (var hive = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64)) {
                using (var key = hive.OpenSubKey(PolicyPath)) {
                    object value = key == null ? null : key.GetValue("NoAutoUpdate");
                    if (value == null) status.Text = "当前策略：未配置禁止自动更新";
                    else if (key.GetValueKind("NoAutoUpdate") != RegistryValueKind.DWord)
                        status.Text = "当前策略：值类型异常，请检查原设置";
                    else status.Text = (int)value == 1 ? "当前策略：已设置阻止自动更新" : "当前策略：未设置阻止自动更新（值 " + value + "）";
                }
                using (var key = hive.OpenSubKey(BackupPath)) {
                    hasBackup = key != null && key.GetValue("OriginalPolicy") != null;
                    backup.Text = hasBackup ? "恢复备份：已找到（执行恢复时校验）" : "恢复备份：无";
                    restoreService.Enabled = operation == null && key != null && key.GetValue("OriginalService") != null;
                }
            }
            restore.Enabled = operation == null && hasBackup;
            AddLog("已读取当前配置。");
        } catch (Exception ex) {
            status.Text = "当前策略：读取失败";
            backup.Text = "恢复备份：未知";
            restore.Enabled = false;
            restoreService.Enabled = false;
            AddLog("读取失败：" + ex.Message);
        }
        try {
            using (var controller = new ServiceController("wuauserv"))
            using (var hive = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
            using (var key = hive.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\wuauserv")) {
                object start = key == null ? null : key.GetValue("Start");
                string mode = Object.Equals(start, 4) ? "禁用" : Object.Equals(start, 2) ? "自动" : Object.Equals(start, 3) ? "手动" : "未知";
                serviceStatus.Text = "更新服务：" + controller.Status + "   |   启动方式：" + mode;
            }
        } catch (Exception ex) { serviceStatus.Text = "更新服务：读取失败"; AddLog(ex.Message); }
    }

    private void BeginOperation(string action)
    {
        if (operation != null) return;
        string script = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "WindowsUpdateControl.ps1");
        if (!File.Exists(script)) {
            AddLog("缺少 WindowsUpdateControl.ps1，请完整解压程序包后重试。");
            return;
        }
        disable.Enabled = restore.Enabled = refresh.Enabled = disableService.Enabled = restoreService.Enabled = drivers.Enabled = false;
        try {
            string engine = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                @"System32\WindowsPowerShell\v1.0\powershell.exe");
            var info = new ProcessStartInfo(engine,
                "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File \"" + script + "\" -Action " + action);
            info.UseShellExecute = true;
            info.Verb = "runas";
            info.WindowStyle = ProcessWindowStyle.Hidden;
            currentAction = action;
            operation = Process.Start(info);
            if (operation == null) throw new InvalidOperationException("无法启动操作进程。");
            AddLog("正在执行：" + ActionName(action) + "……");
            timer.Start();
        } catch (Win32Exception ex) {
            AddLog(ex.NativeErrorCode == 1223 ? "已取消管理员授权，未执行操作。" : "启动失败：" + ex.Message);
            ResetButtons();
        } catch (Exception ex) {
            AddLog("启动失败：" + ex.Message);
            ResetButtons();
        }
    }

    private void PollOperation()
    {
        try {
            if (operation == null || !operation.HasExited) return;
            int code = operation.ExitCode;
            timer.Stop();
            operation.Dispose();
            operation = null;
            if (code == 0) {
                AddLog("完成：" + ActionName(currentAction) + "。恢复操作以备份的原状态为准。");
                AddLog("请择时重启后检查。已安排或正在安装的更新不会被取消。");
            } else {
                AddLog("操作失败，退出码：" + code + "。请运行对应 CMD 入口查看详细错误；已有备份会保留。");
            }
            ResetButtons();
        } catch (Exception ex) {
            timer.Stop();
            AddLog("无法跟踪操作结果：" + ex.Message + "。请稍后重新查看状态。");
            if (operation != null) operation.Dispose();
            operation = null;
            ResetButtons();
        }
    }

    private void ResetButtons()
    {
        disable.Enabled = refresh.Enabled = disableService.Enabled = drivers.Enabled = operation == null;
        RefreshStatus();
    }

    private static string ActionName(string action)
    {
        switch (action) {
            case "Disable": return "阻止自动更新";
            case "Restore": return "恢复策略原设置";
            case "DisableService": return "禁用并停止 Windows Update 服务";
            case "RestoreService": return "恢复服务原设置";
            default: return action;
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) { timer.Dispose(); if (operation != null) operation.Dispose(); }
        base.Dispose(disposing);
    }

    [STAThread]
    public static void Main(string[] args)
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        if (args.Length == 1 && args[0] == "--drivers") {
            using (var identity = System.Security.Principal.WindowsIdentity.GetCurrent()) {
                if (!(new System.Security.Principal.WindowsPrincipal(identity)).IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator)) {
                    MessageBox.Show("请通过主窗口打开驱动更新管理并允许管理员授权。", "需要管理员权限");
                    return;
                }
            }
            Application.Run(new DriverUpdatesForm());
        } else Application.Run(new UpdateControlForm());
    }
}
