@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0WindowsUpdateControl.ps1" -Action RestoreService -Pause
exit /b %errorlevel%
