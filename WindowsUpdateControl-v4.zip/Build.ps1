#requires -Version 5.1
$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) {
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
}
if (-not (Test-Path -LiteralPath $compiler)) { throw '.NET Framework C# compiler was not found.' }
$arguments = @('/nologo', '/target:winexe', '/platform:anycpu',
    ('/out:' + (Join-Path $PSScriptRoot 'WindowsUpdateControl.exe')),
    '/reference:System.Windows.Forms.dll', '/reference:System.Drawing.dll',
    '/reference:System.ServiceProcess.dll', '/reference:System.Web.Extensions.dll',
    '/reference:Microsoft.CSharp.dll',
    (Join-Path $PSScriptRoot 'WindowsUpdateControlGui.cs'),
    (Join-Path $PSScriptRoot 'DriverUpdates.cs'))
& $compiler @arguments
if ($LASTEXITCODE -ne 0) { throw ('Build failed: ' + $LASTEXITCODE) }
Write-Host 'Build succeeded: WindowsUpdateControl.exe'
