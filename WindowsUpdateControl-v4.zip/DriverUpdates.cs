using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

public sealed class DriverItem
{
    public string UpdateId { get; set; }
    public int Revision { get; set; }
    public string Title { get; set; }
    public string Category { get; set; }
    public string DriverClass { get; set; }
    public string HardwareId { get; set; }
    public bool Hidden { get; set; }
    public string Key { get { return UpdateId + ":" + Revision; } }
}

public static class DriverRules
{
    public static bool IsExtension(string value) {
        return String.Equals(value, "Extension", StringComparison.OrdinalIgnoreCase);
    }
    public static string Category(string cls, string name) {
        if (String.Equals(cls, "Display", StringComparison.OrdinalIgnoreCase)) return "显卡";
        if (String.Equals(cls, "MEDIA", StringComparison.OrdinalIgnoreCase) ||
            String.Equals(cls, "AudioEndpoint", StringComparison.OrdinalIgnoreCase)) return "声卡";
        // Generic System/ComputeAccelerator classes alone are not sufficient to identify an NPU.
        if (System.Text.RegularExpressions.Regex.IsMatch(name ?? "",
            @"\bNPU\b|neural|AI Boost|Ryzen AI|Hexagon.*(NPU|processor)",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase)) return "NPU";
        return null;
    }
    public static bool Allowed(string category) {
        return category == "NPU" || category == "声卡" || category == "显卡";
    }
    public static bool InScope(DriverItem item, bool extensionOnly) {
        return Allowed(item.Category) && (!extensionOnly || IsExtension(item.DriverClass));
    }
    public static string ResolveCategory(string cls, string model, string hardwareId, Dictionary<string, string> map) {
        string category = null;
        if (!String.IsNullOrEmpty(hardwareId)) map.TryGetValue(hardwareId, out category);
        if (category == null && !IsExtension(cls) &&
            !String.Equals(cls, "SoftwareComponent", StringComparison.OrdinalIgnoreCase))
            category = Category(cls, model);
        return Allowed(category) ? category : null;
    }
}

public interface IDriverStore {
    List<DriverItem> Load();
    void Save(List<DriverItem> items);
}

public sealed class RegistryDriverStore : IDriverStore
{
    private const string Path = @"SOFTWARE\WindowsUpdateControlLocal";
    public List<DriverItem> Load() {
        using (var hive = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
        using (var key = hive.OpenSubKey(Path)) {
            object raw = key == null ? null : key.GetValue("HiddenDriverUpdates");
            if (raw == null) return new List<DriverItem>();
            if (!(raw is string)) throw new InvalidOperationException("驱动更新备份格式异常。");
            var list = new JavaScriptSerializer().Deserialize<List<DriverItem>>((string)raw);
            if (list == null) throw new InvalidOperationException("驱动更新备份无效。");
            var seen = new HashSet<string>();
            foreach (var item in list) {
                Guid id;
                if (item == null || !Guid.TryParse(item.UpdateId, out id) || item.Revision < 0 ||
                    !DriverRules.Allowed(item.Category) || !seen.Add(item.Key))
                    throw new InvalidOperationException("驱动更新备份无效，已停止操作。");
            }
            return list;
        }
    }
    public void Save(List<DriverItem> items) {
        using (var hive = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
        using (var key = hive.CreateSubKey(Path)) {
            key.SetValue("HiddenDriverUpdates", new JavaScriptSerializer().Serialize(items), RegistryValueKind.String);
            key.Flush();
        }
    }
}

public interface IDriverAgent {
    List<DriverItem> Scan();
    // Returns false when a hidden entry is no longer offered by the update source.
    bool SetHidden(DriverItem item, bool hidden, Action beforeHide);
}

public sealed class WindowsDriverAgent : IDriverAgent
{
    private static void Release(object obj) { if (obj != null && Marshal.IsComObject(obj)) Marshal.FinalReleaseComObject(obj); }
    private static Dictionary<string, string> HardwareCategories() {
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        using (var hive = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
        using (var root = hive.OpenSubKey(@"SYSTEM\CurrentControlSet\Enum")) {
            if (root == null) throw new InvalidOperationException("无法读取本机硬件信息。");
            foreach (string bus in root.GetSubKeyNames()) using (var busKey = root.OpenSubKey(bus)) {
                if (busKey == null) continue;
                foreach (string device in busKey.GetSubKeyNames()) using (var deviceKey = busKey.OpenSubKey(device)) {
                    if (deviceKey == null) continue;
                    foreach (string instance in deviceKey.GetSubKeyNames()) using (var key = deviceKey.OpenSubKey(instance)) {
                        if (key == null) continue;
                        string category = DriverRules.Category(key.GetValue("Class") as string,
                            Convert.ToString(key.GetValue("FriendlyName")) + " " + Convert.ToString(key.GetValue("DeviceDesc")));
                        if (category == null) continue;
                        // Use hardware IDs, not broad compatible IDs that can match unrelated devices.
                        foreach (string id in key.GetValue("HardwareID") as string[] ?? new string[0]) {
                            string previous;
                            if (map.TryGetValue(id, out previous) && previous != category) map[id] = null;
                            else if (!map.ContainsKey(id)) map[id] = category;
                        }
                    }
                }
            }
        }
        return map;
    }

    public List<DriverItem> Scan() {
        var map = HardwareCategories();
        var list = new List<DriverItem>();
        dynamic session = null, searcher = null, result = null, updates = null;
        try {
            session = Activator.CreateInstance(Type.GetTypeFromProgID("Microsoft.Update.Session", true));
            session.ClientApplicationID = "WindowsUpdateControl.DriverUpdates";
            searcher = session.CreateUpdateSearcher();
            result = searcher.Search("IsInstalled=0 and Type='Driver' and IsHidden=0");
            if ((int)result.ResultCode != 2) throw new InvalidOperationException("更新扫描未完整成功，请重试。");
            updates = result.Updates;
            for (int i = 0; i < (int)updates.Count; i++) {
                dynamic update = null, identity = null;
                try {
                    update = updates.Item(i);
                    identity = update.Identity;
                    string cls = (string)update.DriverClass;
                    string hw = (string)update.DriverHardwareID;
                    // Primary driver classes may be identified directly. Extension and software
                    // components must match a known hardware ID; vendor/title guesses are excluded.
                    string category = DriverRules.ResolveCategory(cls, (string)update.DriverModel, hw, map);
                    if (!DriverRules.Allowed(category)) continue;
                    list.Add(new DriverItem { UpdateId = (string)identity.UpdateID, Revision = (int)identity.RevisionNumber,
                        Title = (string)update.Title, Category = category, DriverClass = cls, HardwareId = hw, Hidden = false });
                } finally { Release(identity); Release(update); }
            }
            return list;
        } finally { Release(updates); Release(result); Release(searcher); Release(session); }
    }

    public bool SetHidden(DriverItem item, bool hidden, Action beforeHide) {
        Guid id;
        if (!Guid.TryParse(item.UpdateId, out id) || item.Revision < 0 || !DriverRules.Allowed(item.Category))
            throw new InvalidOperationException("更新标识无效。");
        dynamic session = null, searcher = null, result = null, updates = null, update = null;
        try {
            session = Activator.CreateInstance(Type.GetTypeFromProgID("Microsoft.Update.Session", true));
            session.ClientApplicationID = "WindowsUpdateControl.DriverUpdates";
            searcher = session.CreateUpdateSearcher();
            string query = "IsInstalled=0 and Type='Driver' and UpdateID='" + id.ToString() +
                "' and RevisionNumber=" + item.Revision;
            result = searcher.Search(query + " and IsHidden=0 or " + query + " and IsHidden=1");
            if ((int)result.ResultCode != 2) throw new InvalidOperationException("更新查询未完整成功。");
            updates = result.Updates;
            if ((int)updates.Count == 0) return false;
            if ((int)updates.Count != 1) throw new InvalidOperationException("更新标识不唯一，已停止操作。");
            update = updates.Item(0);
            if ((bool)update.IsInstalled || (bool)update.IsMandatory)
                throw new InvalidOperationException("更新已安装或不可隐藏。");
            if (hidden && (bool)update.IsHidden)
                throw new InvalidOperationException("更新已被其他操作隐藏，未接管该条目。");
            if (hidden) beforeHide();
            update.IsHidden = hidden;
            if ((bool)update.IsHidden != hidden) throw new InvalidOperationException("更新隐藏状态核对失败。");
            return true;
        } finally { Release(update); Release(updates); Release(result); Release(searcher); Release(session); }
    }
}

public sealed class DriverManager
{
    private readonly IDriverStore store;
    private readonly IDriverAgent agent;
    public DriverManager(IDriverStore store, IDriverAgent agent) { this.store = store; this.agent = agent; }
    public List<DriverItem> Scan() {
        var saved = store.Load();
        var visible = agent.Scan();
        // A pending backup may exist if the previous hide failed after backup was written.
        foreach (var item in saved) { item.Hidden = true; visible.RemoveAll(v => v.Key == item.Key); visible.Add(item); }
        return visible;
    }
    public List<DriverItem> Saved() { var list = store.Load(); foreach (var item in list) item.Hidden = true; return list; }
    public void Apply(DriverItem item, bool hidden) {
        if (!DriverRules.Allowed(item.Category)) throw new InvalidOperationException("未获授权的硬件类别。");
        var saved = store.Load();
        var prior = saved.Find(i => i.Key == item.Key);
        if (!hidden && prior == null) throw new InvalidOperationException("仅可恢复本程序备份的条目。");
        if (hidden && prior != null) throw new InvalidOperationException("该条目已有备份，请先恢复或核对状态。");
        bool found = agent.SetHidden(item, hidden, delegate {
            saved.Add(item);
            store.Save(saved); // Must succeed BEFORE changing the update state.
        });
        if (!found) throw new InvalidOperationException("该版本当前不可查询，保留备份；可稍后重试。");
        if (!hidden) { saved.RemoveAll(i => i.Key == item.Key); store.Save(saved); }
    }
}

public sealed class DriverUpdatesForm : Form
{
    private readonly DataGridView grid = new DataGridView();
    private readonly ComboBox category = new ComboBox();
    private readonly CheckBox extensions = new CheckBox();
    private readonly Button scan = new Button(), hide = new Button(), undo = new Button();
    private readonly TextBox log = new TextBox();
    private readonly ProgressBar progress = new ProgressBar();
    private readonly DriverManager manager = new DriverManager(new RegistryDriverStore(), new WindowsDriverAgent());
    private List<DriverItem> items = new List<DriverItem>();
    private bool busy;

    public DriverUpdatesForm() {
        Text = "驱动扩展更新 · NPU / 声卡 / 显卡";
        Font = new Font("Microsoft YaHei UI", 9F);
        ClientSize = new Size(920, 620);
        MinimumSize = new Size(860, 600);
        StartPosition = FormStartPosition.CenterScreen;
        var note = new Label { Text = "扫描后勾选要隐藏的更新，保留手动安装。新版本需重新扫描；请先恢复 Windows Update 服务。\r\n仅列出能识别为 NPU、声卡、显卡的条目；扩展需匹配硬件 ID，归属不明的条目不处理。", Location = new Point(18, 16), Size = new Size(884, 44) };
        category.DropDownStyle = ComboBoxStyle.DropDownList;
        category.Items.AddRange(new object[] { "全部三类", "NPU", "声卡", "显卡" });
        category.SelectedIndex = 0;
        category.SetBounds(18, 70, 130, 30);
        extensions.Text = "仅 Extension 扩展驱动";
        extensions.Checked = true;
        extensions.SetBounds(165, 70, 220, 30);
        scan.Text = "扫描更新"; hide.Text = "隐藏勾选项"; undo.Text = "恢复勾选项";
        scan.SetBounds(432, 68, 145, 34); hide.SetBounds(594, 68, 145, 34); undo.SetBounds(756, 68, 145, 34);
        grid.SetBounds(18, 116, 884, 326);
        grid.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
        grid.AllowUserToAddRows = grid.AllowUserToDeleteRows = false;
        grid.RowHeadersVisible = false;
        grid.AutoGenerateColumns = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.Columns.Add(new DataGridViewCheckBoxColumn { Name = "Pick", HeaderText = "选择", Width = 48 });
        grid.Columns.Add("Category", "类别"); grid.Columns[1].Width = 60;
        grid.Columns.Add("State", "状态"); grid.Columns[2].Width = 154;
        grid.Columns.Add("Class", "驱动类型"); grid.Columns[3].Width = 132;
        grid.Columns.Add("Title", "更新名称"); grid.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        for (int i = 1; i < grid.Columns.Count; i++) grid.Columns[i].ReadOnly = true;
        log.SetBounds(18, 478, 884, 124); log.Multiline = true; log.ReadOnly = true; log.ScrollBars = ScrollBars.Vertical;
        log.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        progress.SetBounds(18, 451, 884, 15); progress.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        Controls.AddRange(new Control[] { note, category, extensions, scan, hide, undo, grid, progress, log });
        category.SelectedIndexChanged += delegate { RenderItems(); };
        extensions.CheckedChanged += delegate { RenderItems(); };
        scan.Click += delegate { Run(delegate { var found = manager.Scan(); Ui(delegate { items = found; RenderItems(); WriteLog("扫描完成：匹配三类的条目共 " + found.Count + " 个。未匹配的驱动不处理。"); }); }); };
        hide.Click += delegate { ApplySelected(true); };
        undo.Click += delegate { ApplySelected(false); };
        FormClosing += delegate(object sender, FormClosingEventArgs e) { if (busy) { e.Cancel = true; WriteLog("操作进行中，请等待完成后关闭。"); } };
        try { items = manager.Saved(); RenderItems(); }
        catch (Exception ex) { WriteLog(ex.Message); }
        WriteLog("扫描不下载或安装更新。已备份条目可直接勾选恢复；取消“仅 Extension”可查看主驱动及能匹配的配套驱动。");
    }

    private void Ui(Action action) { if (!IsDisposed) BeginInvoke(action); }
    private void WriteLog(string message) { log.AppendText(DateTime.Now.ToString("HH:mm:ss") + "  " + message + Environment.NewLine); }
    private void RenderItems() {
        grid.Rows.Clear();
        foreach (var item in items) {
            if (!DriverRules.InScope(item, extensions.Checked) ||
                (category.SelectedIndex != 0 && item.Category != (string)category.SelectedItem)) continue;
            int index = grid.Rows.Add(false, item.Category, item.Hidden ? "本程序备份（可恢复）" : "可隐藏", item.DriverClass, item.Title);
            grid.Rows[index].Tag = item;
        }
    }
    private void ApplySelected(bool hidden) {
        grid.EndEdit();
        var chosen = new List<DriverItem>();
        foreach (DataGridViewRow row in grid.Rows) {
            var item = (DriverItem)row.Tag;
            if (Object.Equals(row.Cells[0].Value, true) && item.Hidden != hidden) chosen.Add(item);
        }
        if (chosen.Count == 0) { WriteLog(hidden ? "请勾选可隐藏条目。" : "请勾选本程序备份的条目。"); return; }
        Run(delegate {
            foreach (var item in chosen) {
                try {
                    manager.Apply(item, hidden);
                    Ui(delegate { item.Hidden = hidden; WriteLog((hidden ? "已隐藏：" : "已恢复：") + item.Title); });
                } catch (Exception ex) { Ui(delegate { WriteLog("失败：" + item.Title + " — " + ex.Message); }); }
            }
            // Reload durable backups even when a hide failed after creating its backup.
            var saved = manager.Saved();
            Ui(delegate {
                foreach (var item in items) item.Hidden = saved.Any(s => s.Key == item.Key);
                RenderItems();
            });
        });
    }
    private void Run(Action work) {
        if (busy) return;
        busy = true;
        scan.Enabled = hide.Enabled = undo.Enabled = category.Enabled = extensions.Enabled = grid.Enabled = false;
        progress.Style = ProgressBarStyle.Marquee;
        WriteLog("处理中，扫描可能需要几分钟……");
        var worker = new Thread(delegate() {
            Mutex mutex = null; bool locked = false;
            try {
                mutex = new Mutex(false, @"Global\WindowsUpdateControlDriverUpdatesV1");
                try { locked = mutex.WaitOne(0); } catch (AbandonedMutexException) { locked = true; }
                if (!locked) throw new InvalidOperationException("另一个驱动更新操作正在执行。");
                work();
            } catch (Exception ex) { Ui(delegate { WriteLog("失败：" + ex.Message + "。如更新服务被禁用，请先恢复服务后再试。"); }); }
            finally {
                if (locked) mutex.ReleaseMutex();
                if (mutex != null) mutex.Dispose();
                Ui(delegate {
                    busy = false;
                    scan.Enabled = hide.Enabled = undo.Enabled = category.Enabled = extensions.Enabled = grid.Enabled = true;
                    progress.Style = ProgressBarStyle.Blocks;
                });
            }
        });
        worker.IsBackground = true;
        worker.SetApartmentState(ApartmentState.STA);
        worker.Start();
    }
}
